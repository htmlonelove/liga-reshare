export const createPreviewContainerMarkup = () => '<div class="input-upload__preview"></div>';
