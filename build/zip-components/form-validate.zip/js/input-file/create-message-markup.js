export const createMessageMarkup = (message) => `<div class="input-upload__message">${message}</div>`;
