const baseCountryCode = '+7';
const baseMatrix = ' (___) ___ __ __';
const phoneLength = baseCountryCode.length + baseMatrix.length;

const onInputPhoneInput = ({target}) => {
  const matrix = `${baseCountryCode}${baseMatrix}`;
  const def = matrix.replace(/\D/g, '');
  let i = 0;
  let val = target.value.replace(/\D/g, '');
  if (def.length >= val.length) {
    val = def;
  }
  target.value = matrix.replace(/./g, (a) => {
    if (/[_\d]/.test(a) && i < val.length) {
      return val.charAt(i++);
    } else if (i >= val.length) {
      return '';
    } else {
      return a;
    }
  });
};

const onFocusPhoneInput = ({target}) => {
  if (!target.value) {
    target.value = baseCountryCode;
  }

  target.addEventListener('input', onInputPhoneInput);
  target.addEventListener('blur', onBlurPhoneInput);
  target.addEventListener('keydown', onKeydownPhoneInput);
  target.addEventListener('paste', onPastePhoneInput);
};

const onPastePhoneInput = (e) => {
  setTimeout(() => {
    if (e.target.value.startsWith('+7')) {
      return;
    }
    if (e.target.value.startsWith('+8')) {
      e.target.value = `+7${e.target.value.slice(3)}`;
      return;
    }
    e.target.value = '';
  });
};

// 89114565157
// +79114565157
// 4444444444

const onKeydownPhoneInput = (e) => {
  if (e.keyCode === 39 || e.keyCode === 37 || e.keyCode === 13) {
    //return;
  }
  setTimeout(() => {
    if (e.target.selectionStart < 3 && e.keyCode !== 39 || e.keyCode !== 37) {
      console.log(e.target.selectionEnd);
      e.preventDefault();
    }
  })

};

const onBlurPhoneInput = ({target}) => {
  if (target.value === baseCountryCode) {
    const parent = target.closest('[data-validate-type="phone"]');
    target.value = '';
    if (!parent.hasAttribute('data-required')) {
      parent.classList.remove('is-valid');
      parent.classList.remove('is-invalid');
      const parentMessage = parent.querySelector('.input-message');
      if (parentMessage) {
        parentMessage.remove();
      }
    }
    parent.classList.remove('not-empty');
    target.removeEventListener('input', onInputPhoneInput);
    target.removeEventListener('blur', onBlurPhoneInput);
  }
};

export const initPhoneInput = (parent) => {
  const input = parent.querySelector('input');
  parent.dataset.phoneLength = phoneLength;
  input.addEventListener('focus', onFocusPhoneInput);
};
