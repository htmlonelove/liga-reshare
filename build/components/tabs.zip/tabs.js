const removeAllActiveClasses = (tab) => {
  const controlElements = tab.querySelectorAll(':scope > [data-tabs="controls"] [data-tabs="control"]');
  const tabElements = tab.querySelectorAll(':scope > [data-tabs="content"] [data-tabs="element"]');
  [...controlElements, ...tabElements].forEach((element) => {
    if (element) {
      element.classList.remove('is-active');
    }
  });
};

const updateTabHeight = (tab, dataHeight, contentBlock) => {
  window.addEventListener('resize', () => {
    if (dataHeight === 'max') {
      contentBlock.style.height = returnMaxHeight(tab) + 'px';
    } else {
      contentBlock.style.height = tab.querySelector(':scope > [data-tabs="content"] [data-tabs="element"].is-active').scrollHeight + 'px';
    }
  });
};

const returnActiveIndex = (tab) => {
  let index = 0;
  let flag = true;
  const controls = tab.querySelectorAll(':scope > [data-tabs="controls"] [data-tabs="control"]');
  controls.forEach((control, i) => {
    if (control.classList.contains('is-active')) {
      if (flag) {
        index = i;
        flag = false;
      }
    }
  });
  return index;
};

const returnMaxHeight = (tab) => {
  const tabsElements = tab.querySelectorAll(':scope > [data-tabs="content"] [data-tabs="element"]');
  let heights = [];
  tabsElements.forEach((element) => {
    heights.push(element.scrollHeight);
  });
  heights.sort();
  return heights[heights.length - 1];
};

const setTabStartState = (tab) => {
  const controls = tab.querySelectorAll(':scope > [data-tabs="controls"] [data-tabs="control"]');
  const tabsElements = tab.querySelectorAll(':scope > [data-tabs="content"] [data-tabs="element"]');
  const contentBlock = tab.querySelector(':scope > [data-tabs="content"]');
  const activeIndex = returnActiveIndex(tab);

  removeAllActiveClasses(tab);
  controls[activeIndex].classList.add('is-active');
  tabsElements[activeIndex].classList.add('is-active');
  tab.classList.add('is-initialized');

  const blockHeight = tab.dataset.height === 'max' ? returnMaxHeight(tab) : tabsElements[activeIndex].scrollHeight;

  contentBlock.style.height = blockHeight + 'px';
};


const initTabAction = (tab) => {
  let delay = tab.dataset.delay;
  if (!delay) {
    tab.classList.add('no-transition');
    delay = 0;
  }
  const contentBlock = tab.querySelector(':scope > [data-tabs="content"]');
  const controls = tab.querySelectorAll(':scope > [data-tabs="controls"] [data-tabs="control"]');
  const tabsElements = tab.querySelectorAll(':scope > [data-tabs="content"] [data-tabs="element"]');
  const dataHeight = tab.dataset.height;

  setTabStartState(tab);

  updateTabHeight(tab, dataHeight, contentBlock);

  controls.forEach((control, index) => {
    control.addEventListener('click', (evt) => {
      evt.preventDefault();
      const parent = evt.target.closest('[data-tabs="parent"]');

      if (control.classList.contains('is-active') || parent.classList.contains('no-action')) {
        return;
      }

      const activeControl = tab.querySelector(':scope > [data-tabs="controls"] [data-tabs="control"].is-active');
      const activeTabElement = tab.querySelector(':scope > [data-tabs="content"] [data-tabs="element"].is-active');
      const currentHeight = contentBlock.scrollHeight;
      const newHeight = tabsElements[index].scrollHeight;

      parent.classList.add('no-action');

      if (activeControl) {
        activeControl.classList.remove('is-active');
      }

      if (activeTabElement) {
        activeTabElement.classList.remove('is-active');
      }

      if (currentHeight > newHeight) {
        setTimeout(() => {
          if (dataHeight !== 'max') {
            contentBlock.style.height = newHeight + 'px';
          }
          control.classList.add('is-active');
          tabsElements[index].classList.add('is-active');
          parent.classList.remove('no-action');
        }, delay);
      } else {
        if (dataHeight !== 'max') {
          contentBlock.style.height = newHeight + 'px';
        }
        setTimeout(() => {
          control.classList.add('is-active');
          tabsElements[index].classList.add('is-active');
          parent.classList.remove('no-action');
        }, delay);
      }
    });
  });
};

const initTabs = () => {
  const tabs = document.querySelectorAll('[data-tabs="parent"]:not(.is-initialized)');
  tabs.forEach((tab) => initTabAction(tab));
};

window.initTabs = initTabs;

export default initTabs;
