import {initPhoneMask} from './phone-mask';

window.addEventListener('DOMContentLoaded', () => {
  window.addEventListener('load', () => {
    initPhoneMask();
  });
});
